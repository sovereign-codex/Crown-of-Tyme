"""
Base AVOT Template — used by the generator to birth new autonomous modules.
"""

def speak():
    return "I am a template AVOT, awaiting resonance."
