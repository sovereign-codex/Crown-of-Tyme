# Placeholder for GardenFlame-Kodex/scrolls/README.md
